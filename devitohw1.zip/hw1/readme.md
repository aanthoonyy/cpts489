## Overview

Replicated UWB website

## Screenshots of my vs UWB

### My version

- ![pic1](./images/Picture1.png)
- ![pic2](./images/Picture2.png)
- ![pic3](./images/Picture3.png)

### UWB

- ![pic4](./images/Picture4.png)
- ![pic5](./images/Picture5.png)
- ![pic6](./images/Picture6.png)

I think it turned out pretty good :D
